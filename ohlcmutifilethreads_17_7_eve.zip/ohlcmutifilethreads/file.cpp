    //  g++ -std=c++17 -Wall -pedantic -O3 -s file.cpp -lpthread
     
    #include <future>
    #include <mutex>
    #include <iostream>
    #include <chrono>
    #include <log4cxx/logger.h>
    #include <log4cxx/basicconfigurator.h>
    #include <log4cxx/helpers/exception.h>
    #include <log4cxx/helpers/stringhelper.h>
    #include <log4cxx/xml/domconfigurator.h>
    #include <log4cxx/helpers/exception.h>
    #include <log4cxx/ndc.h>
    #include <log4cxx/level.h>
    #include <unistd.h>

    //make up a lock for output stream
using namespace std;
using namespace log4cxx;
using namespace log4cxx::helpers;

namespace logger
{
    int result = EXIT_SUCCESS;
    enum {LOG4CXX_POLL_INTERVAL = 60, };
    const char* LOG4CXX_PROPERTY_FILE ="config.xml";
}

    auto g_lock()
    {
        static std::mutex m; // a global living mutyex
        return std::unique_lock<decltype(m)>(m); // RAII based lock
    }
     
    void func_1(std::size_t n)
    {
        for(size_t i=0; i<n; ++i)
        {
            using namespace std::literals;
            std::this_thread::sleep_for(100ms); //faster than func_2
            {
                auto lk = g_lock(); //keep output locked up to }
                // std::cout << "func_1 - iteration " << i << std::endl;

                           log4cxx::xml::DOMConfigurator::configureAndWatch(logger::LOG4CXX_PROPERTY_FILE,logger::LOG4CXX_POLL_INTERVAL);
                
                   LoggerPtr rootLogger = Logger::getLogger("");
                
                        NDC::push("trivial context");
                        std::string aa =  to_string(i);
                  rootLogger->error("func_1");
                  sleep(1);
            }
        }
    }
     
    void func_2(std::size_t n)
    {
        for(size_t i=0; i<n; ++i)
        {
            using namespace std::literals;
            std::this_thread::sleep_for(200ms); //slower than func_1
            {
                auto lk = g_lock(); //keep output locked up to }
                // std::cout << "func_2 - iteration " << i << std::endl;
                
                log4cxx::xml::DOMConfigurator::configureAndWatch(logger::LOG4CXX_PROPERTY_FILE,logger::LOG4CXX_POLL_INTERVAL);
                
                   LoggerPtr rootLogger = Logger::getLogger("");
                
                        NDC::push("trivial context");
                      
                  rootLogger->info("func2");
                  sleep(1);


            }
        }
    }
     
    int main()
    {
     
        // create the "futures"
        auto h1 = std::async(std::launch::async, func_1, 10);
        auto h2 = std::async(std::launch::async, func_2, 10);
     
        // execute them
        h1.get(), h2.get();
     
        std::cout << "joined" << std::endl;
        return 0;
    }