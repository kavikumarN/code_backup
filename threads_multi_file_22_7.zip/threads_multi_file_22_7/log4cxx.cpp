
#include <stdlib.h>
#include <string.h>
#include <bits/stdc++.h> 
#include <log4cxx/logger.h>
#include <log4cxx/basicconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/helpers/stringhelper.h>
#include <log4cxx/xml/domconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/ndc.h>
#include <log4cxx/level.h>
#include "zhelpers.hpp"
#include <unistd.h>
using namespace std;
using namespace log4cxx;
using namespace log4cxx::helpers;

class Filemover
{
public:
    std::string symbols[6] = {"usdeur","usdjpy","usdcad","usdaud","usdnzd","usdgbp"};


int result = EXIT_SUCCESS;
enum {LOG4CXX_POLL_INTERVAL = 60, };

int usdcad(std::string symbol2) { return 0; }

int usdaud(std::string symbol2) { return 0; }

int usdnzd(std::string symbol2) { return 0; }

int usdgbp(std::string symbol2) { return 0; }


int usdeur(std::string symbol1) {
            try
            {      
                        // if we do not specify the log4j properties file, we must use
                        // BasicConfigurator::configure();
                        // else we pass in the file name with path and watch time
                        //
                        const char* LOG4CXX_PROPERTY_FILE ="usdeur.xml";

                        log4cxx::xml::DOMConfigurator::configureAndWatch(LOG4CXX_PROPERTY_FILE,LOG4CXX_POLL_INTERVAL);
                        // a thread will be created that will periodically
                        // check if the LOG4CXX_PROPERTY_FILE has been created or
                        // modified. The period is determined by the LOG4CXX_POLL_INTERVAL
                        // argument in seconds. If a change or file creation is detected, then
                        // LOG4CXX_PROPERTY_FILE is read to configure log4j.

                        LoggerPtr rootLogger = Logger::getLogger("");



                        // get the logger setting by name "sd"

                        NDC::push("trivial context");
                        // NDC (nested diagnostic context) for multithread logging purpose

                      
                        rootLogger->info(symbol1);
                        sleep(1);
                        

                        
              }
                catch(Exception&)
                {
                result = EXIT_FAILURE;
                }



      return result;
      }

int usdjpy(std::string symbol2) {
            try
            {      
                        // if we do not specify the log4j properties file, we must use
                        // BasicConfigurator::configure();
                        // else we pass in the file name with path and watch time
                        //
                        const char* LOG4CXX_PROPERTY_FILE ="usdjpy.xml";

                        log4cxx::xml::DOMConfigurator::configureAndWatch(LOG4CXX_PROPERTY_FILE,LOG4CXX_POLL_INTERVAL);
                        // a thread will be created that will periodically
                        // check if the LOG4CXX_PROPERTY_FILE has been created or
                        // modified. The period is determined by the LOG4CXX_POLL_INTERVAL
                        // argument in seconds. If a change or file creation is detected, then
                        // LOG4CXX_PROPERTY_FILE is read to configure log4j.

                        LoggerPtr rootLogger = Logger::getLogger("");



                        // get the logger setting by name "sd"

                        NDC::push("trivial context");
                        // NDC (nested diagnostic context) for multithread logging purpose

                      
                        rootLogger->info(symbol2);
                        sleep(1);
                        

                        
              }
                catch(Exception&)
                {
                result = EXIT_FAILURE;
                }



return result;
}

int isSubstring(string s1, string s2) 
{ 
	int M = s1.length(); 
	int N = s2.length(); 

	/* A loop to slide pat[] one by one */
	for (int i = 0; i <= N - M; i++) { 
		int j; 

		/* For current index i, check for pattern match */
		for (j = 0; j < M; j++) 
			if (s2[i + j] != s1[j]) 
				break; 

		if (j == M) 
			return i; 
	} 

	return -1; 
} 

void raiseexception(void)
{
// dummy exception
}

};


 int main () {
    //  Prepare our context and subscriber
     Filemover f1;
    int a = 0;
    std::string symbols[6] = {"usdeur","usdjpy","usdcad","usdaud","usdnzd","usdgbp"};
            zmq::context_t context(1);
          zmq::socket_t subscriber (context, ZMQ_SUB);
               subscriber.connect("tcp://localhost:5553");
                        subscriber.setsockopt( ZMQ_SUBSCRIBE,"A",1);
         for(;;)    {                      
                    std::string address = s_recv (subscriber);
                    std::string contents = s_recv (subscriber);

                      for (int i=0;i<6;i++){
                      if(f1.isSubstring(symbols[i],contents)>0) 
                        {
                      //     string function ="f1."
                      //  strcpy(function,symbols[i]);
                        if(symbols[i].compare,"usdeur"==0)
                             f1.usdeur(contents);
                        else if(symbols[i].compare,"usdjpy"==0)
                             f1.usdjpy(contents);
                        else if(symbols[i].compare,"usdcad"==0)
                             f1.usdcad(contents);
                        else if(symbols[i].compare,"usdaud"==0)
                             f1.usdaud(contents);
                        else if(symbols[i].compare,"usdnzd"==0)
                             f1.usdnzd(contents); 
                        else if(symbols[i].compare,"usdgbp"==0)
                             f1.usdgbp(contents);  
                        else f1.raiseexception();                                 



                      }

                      }
                        

         }

   
     
    return a;
}

// g++ log4cxx.cpp  -lapr-1 -laprutil-1 -llog4cxx -lzmq -o output