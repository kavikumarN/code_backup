

//
//  Pubsub envelope publisher
//  Note that the zhelpers.h file also provides s_sendmore
//
// Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>
#include <random>
#include <iostream>
#include "zhelpers.hpp"
#include <sstream>  // for string streams 
#include <string>  // for string 
using namespace std;

int main () {
    //  Prepare our context and publisher
    std::string symbols[6] = {"usdeur","usdjpy","usdcad","usdaud","usdnzd","usdgbp"};
    zmq::context_t context(1);
    zmq::socket_t publisher(context, ZMQ_PUB);
    publisher.bind("tcp://*:1234");
    std::random_device dev;
    std::mt19937 rng(dev());
    std::uniform_int_distribution<std::mt19937::result_type> distr(2000,6000);



    while (1) {
        //  Write two messages, each with an envelope and content

    for(int i=0;i<6;i++)
            {
                std::string msg =symbols[i]+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng))+','+to_string(distr(rng));
                //std::string msg =symbols[i]+','+to_string(dist6(rng))+','+to_string(dist6(rng))+','+to_string(dist6(rng))+','+to_string(dist6(rng))+','+to_string(dist6(rng)+','+to_string(dist6(rng)+','+std::to_string(dist6(rng)+','+std::to_string(dist6(rng));


                // ostringstream strstreamer; 
                // auto * pointingvar = & strstreamer;
                // strstreamer<<symbols[i]<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<','<<dist6(rng)<<endl;
                // string msg = strstreamer.str(); 
               // cout<<i<<":"<<msg<<endl;
                s_sendmore (publisher, "A");
                s_send (publisher, msg);
                s_sendmore (publisher, "B");
                s_send (publisher, msg);
            //    free (pointingvar);
                sleep (1);
            }
    }
    return 0;
}

// g++ pub.cpp -lzmq -o pub