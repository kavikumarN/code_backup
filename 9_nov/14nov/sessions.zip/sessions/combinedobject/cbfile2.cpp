#include <iostream>
#include "cbfile1.hpp"
#include <zmq.hpp>
using namespace std;
int sessionid = 0;




int struct_loader(user_profile &ref)
{
    sessionid++;
    object_capsule.insert(std::make_pair(std::to_string(sessionid), &ref));

    // object_capsule.insert(pair<string,user_profile> ("sessionid",&ref));
    // object_capsule.insert(std::make_pair("example",&ref));
    auto itr = object_capsule.find(std::to_string(sessionid));
   // cout << "itr--->" << itr->second << "\t:\t";
    itr->second->email_id = "ankavikumar@gmail.com";

}

int main()
{   
    user_profile *demo_profile1;
    demo_profile1 = new user_profile(2001, 4254245234252, "steven", "smith", "Male", "IND12345566773", "12345564", "UIDAI", "123456789456", "02-may-1994", "no 234, 1st avenue,", " MG road", " bengaluru", "karnataka", "india", "+919025247848", "INDIAN", "560041", "msg4kavi@gmail.com", true);
    demo_profile1->email_id = "updatedemail@email.com";
    struct_loader(*demo_profile1);
    cout << "\tmain()--->" << demo_profile1 << endl;

    user_profile *demo_profile2;
    demo_profile2 = new user_profile(2002, 4254245234252, "steven", "flemming", "Male", "IND12345566773", "12345564", "UIDAI", "123456789456", "02-may-1994", "no 234, 1st avenue,", " MG road", " bengaluru", "karnataka", "india", "+919025247848", "INDIAN", "560041", "msg4kavi@gmail.com", true);
    struct_loader(*demo_profile2);
    cout << "\tmain()--->" << demo_profile2 << endl;

    user_profile *demo_profile3;
    demo_profile3 = new user_profile(2003, 4254245234252, "steven", "Spielberg", "Male", "IND12345566773", "12345564", "UIDAI", "123456789456", "02-may-1994", "no 234, 1st avenue,", " MG road", " bengaluru", "karnataka", "india", "+919025247848", "INDIAN", "560041", "msg4kavi@gmail.com", true);
    struct_loader(*demo_profile3);
     cout << "\tmain()--->" << demo_profile3 << endl;

       // session_init();

    return 0;
}
