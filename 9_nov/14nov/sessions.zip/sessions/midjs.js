const zmq = require("zeromq/v5-compat")


// socket to talk to server
var requester = zmq.socket('req');

var x = 0;
requester.on("message", function(reply) {
  console.log("Received reply", reply.toString(), );
  x += 1;
  if (x === 3) {
    requester.close();
    process.exit(0);
  }
});

requester.connect("tcp://localhost:5555");

for (var i = 1; i < 4; i++) {
  var aa = "aaa";
  console.log(typeof(aa));
  console.log("Sending request", i, '...');
  requester.send(1);
}

process.on('SIGINT', function() {
  requester.close();
});