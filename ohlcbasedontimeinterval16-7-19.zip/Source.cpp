#include "zhelpers.hpp"
#include <iostream>
#include <ctime>
#include <random>
#include <map>
#include <vector>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <array>
#include <climits>
#include <log4cxx/logger.h>
#include <log4cxx/basicconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/helpers/stringhelper.h>
#include <log4cxx/xml/domconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/ndc.h>
#include <log4cxx/level.h>

using namespace log4cxx;
using namespace log4cxx::helpers;
using namespace std;
namespace Con
{
	zmq::context_t context(1);
	zmq::socket_t publisher(context, ZMQ_PUB);
    void Func() {
		
		publisher.bind("tcp://*:5432");
		usleep(300000);
	}
}

class chartserver
{
public:
	//logger declare
	int result = EXIT_SUCCESS;
	enum {LOG4CXX_POLL_INTERVAL = 60, };
	const char* LOG4CXX_PROPERTY_FILE ="config.xml";


	//map
	map< array<int, 7>, string> eur;
	map< array<int, 7>, string> aur;
	map< array<int, 7>, string> can;
	map< array<int, 7>, string> sng;
	map< array<int, 7>, string> inr;

	string ohlc_sell,ohlc_buy,symbol;

    // zmq::context_t context;
    // zmq::socket_t publisher;
	// zmq::socket_t subscriber;

	
	void sub(){

		cout<<"Subscriber : "<<endl;
		
		string word,tick; 
		array<int, 7> key;
		
		

		std::vector<std::string> vec;

		//  Prepare our context and publisher
		zmq::context_t context(1);
    	zmq::socket_t subscriber (context, ZMQ_SUB);
    	subscriber.connect("tcp://localhost:5553");
    	subscriber.setsockopt( ZMQ_SUBSCRIBE,"tickdata",1);
        Con::Func();
		 while (1) {
			 
			//  Read envelope with address
			std::string address = s_recv (subscriber);
			//  Read message contents
			std::string contents = s_recv (subscriber);

			std::stringstream ss(contents);

				while (getline(ss, word, ',')) {
					vec.push_back(word);
			}
			if (vec.size() > 0) {
				//int sym_cnt=1;
				tick = tick = vec.at(1) + "," + vec.at(2);
				key = { std::stoi(vec.at(3)),std::stoi(vec.at(4)),std::stoi(vec.at(5)),std::stoi(vec.at(6)),std::stoi(vec.at(7)),std::stoi(vec.at(8)) };
			
				 	int sec = std::stoi(vec.at(8));
					//int min = std::stoi(vec.at(7));

				if(vec[0].compare("EUR/USD") == 0){
					
					eur[key] = tick;
					zmq_ohlc(eur,"eur");
					if(sec == 59)
					{
						//cout<<"EUR/USD"<<endl;
						ohlc(eur,"eur_usd");
						eur.clear();
					}
				}
				else if(vec[0].compare("AUR/USD") == 0){
				
					aur[key] = tick;
					zmq_ohlc(aur,"aur");
					if(sec == 59)
					{
						//cout<<"AUR/USD"<<endl;
						ohlc(aur,"aur_usd");
						aur.clear();
					}

				}
				else if(vec[0].compare("CAN/USD") == 0){
				
					can[key] = tick;
					zmq_ohlc(can,"can");
					if(sec == 59)
					{
						//cout<<"CAN/USD"<<endl;
						ohlc(can,"can_usd");
						can.clear();
					}

				}
				else if(vec[0].compare("SNG/USD") == 0){
				
					sng[key] = tick;
					zmq_ohlc(sng,"sng");
					if(sec == 59)
					{
						//cout<<"SNG/USD"<<endl;
						ohlc(sng,"sng_usd");
						sng.clear();
					}

				}
				else if(vec[0].compare("INR/USD") == 0){
				
					inr[key] = tick;
					zmq_ohlc(inr,"inr");
					if(sec == 59)
					{
						//cout<<"INR/USD"<<endl;
						ohlc(inr,"inr_usd");
						inr.clear();
					}

				}
				else{
					
				}
				
				vec.clear();
			}

    	}
	}
	void connect(){
		            
	}
	void ohlc(map< array<int, 7>, string> sym,string fname){

					int temp = 0, temp1 = 0, highbuy = -2147483648 , lowbuy = 2147483647 , highsell = -2147483648, lowsell = 2147483647 , high, low;
					std::string openbuy, closebuy, opensell, closesell,word;
					int count = 1, b = 1, s = 1, x = 1;
					std::string tempstr,time;

					//  // open a file in write mode.
					// 	ofstream outfile_buy;
					// 	ofstream outfile_sell;
					// 	outfile_buy.open("/home/lk/Documents/worklog/Database/"+fname+"_buy.csv", ios::app);
					// 	outfile_sell.open("/home/lk/Documents/worklog/Database/"+fname+"_sell.csv", ios::app);
				
					//logger 
	    			log4cxx::xml::DOMConfigurator::configureAndWatch(LOG4CXX_PROPERTY_FILE,LOG4CXX_POLL_INTERVAL);

	     			LoggerPtr rootLogger = Logger::getLogger("");
		    		
					NDC::push("trivial context");

					
					//cout <<"one minute data : "<<endl;
					for (auto itr = sym.begin(); itr != sym.end(); ++itr) {
						// cout << itr->first[0] << itr->first[1] << itr->first[2] << itr->first[3] << itr->first[4] << itr->first[5] << ',' << itr->second << endl;
						if (count == 1)
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
									tempstr = word;
									if (b == 1)
										{
											openbuy = tempstr;
										}
									if (b == 2)
										{
											opensell = tempstr;
										}
									b++;
							}

						}
						
						if (count == sym.size())
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (s == 1)
								{
									closebuy = tempstr;
								}
								if (s == 2)
								{
									closesell = tempstr;
								}
								s++;
							}
							time = std::to_string(itr->first[0])+'-'+std::to_string(itr->first[1])+'-'+std::to_string(itr->first[2])+'-'+std::to_string(itr->first[3])+'-'+std::to_string(itr->first[4]);
							//cout << itr->first[0] << itr->first[1] << itr->first[2] << itr->first[3] << itr->first[4] << itr->first[5] << ',' << itr->second << endl;
						}
						
						std::stringstream ss(itr->second);
						while (getline(ss, word, ',')) {
							tempstr = word;
							if (x == 1)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highbuy < high)
								{
									
									highbuy = high;
								}
								
								if (lowbuy > low)
								{
									
									lowbuy = low;
								}

							}
							if (x == 2)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highsell < high)
								{
									
									highsell = high;
								}
								
								if (lowsell > low)
								{
									
									lowsell = low;
								}
								
							}
							x++;

						}
						x = 1;
						
						count++;
					}
					std::stringstream outfile_buy;
					std::stringstream outfile_sell;
					outfile_buy <<fname<<",buy,"<<time<<','<<openbuy<<','<<highbuy<<','<<lowbuy<<','<<closebuy<<endl;
					outfile_sell  <<fname<<",sell," <<time<<','<<opensell<<','<<highsell<<','<<lowsell<<','<<closesell<<endl;
					std::string ob = outfile_buy.str();
					std::string os = outfile_sell.str();
					 rootLogger->info(ob);
					 rootLogger->error(os);
					//cout << "Time :" << time <<"openbuy ::" << openbuy << "highbuy ::" << highbuy << "lowbuy ::" << lowbuy << "closebuy ::" << closebuy << endl;
					//cout << "Time :" << time << "opensell ::" << opensell << "highsell ::" << highsell << "lowsell ::" << lowsell << "closesell ::" << closesell << endl;
					sym.clear();

	}	
	
	void fohlc()
	{

		
		
		string word,tick,data; 
		array<int, 7> key;
		

		std::vector<std::string> vec;

		// open a file in write mode.
		ifstream infile;
		infile.open("master_data.csv");

		// Execute a loop until EOF (End of File) 
		cout << "File Reading : \n";
		while (infile) {

			// Read a Line from File 
			getline(infile, data);
			//add data to vector
			std::stringstream ss(data);

			while (getline(ss, word, ',')) {
				vec.push_back(word);
			}
			if (vec.size() > 0) {

				tick = tick = vec.at(1) + "," + vec.at(2);
				
				key = { std::stoi(vec.at(3)),std::stoi(vec.at(4)),std::stoi(vec.at(5)),std::stoi(vec.at(6)),std::stoi(vec.at(7)),std::stoi(vec.at(8)) };
			
				 	int sec = std::stoi(vec.at(8));
					//int min = std::stoi(vec.at(7));

				if(vec[0].compare("EUR/USD") == 0){
					
					eur[key] = tick;
					if(sec == 59)
					{
						//cout<<"EUR/USD"<<endl;
						ohlc(eur,"eur_usd");
						eur.clear();
					}

				}
				else if(vec[0].compare("AUR/USD") == 0){
				
					aur[key] = tick;
					if(sec == 59)
					{
						//cout<<"AUR/USD"<<endl;
						ohlc(aur,"aur_usd");
						aur.clear();
					}

				}
				else if(vec[0].compare("CAN/USD") == 0){
				
					can[key] = tick;
					if(sec == 59)
					{
						//cout<<"CAN/USD"<<endl;
						ohlc(can,"can_usd");
						can.clear();
					}

				}
				else if(vec[0].compare("SNG/USD") == 0){
				
					sng[key] = tick;
					if(sec == 59)
					{
						//cout<<"SNG/USD"<<endl;
						ohlc(sng,"sng_usd");
						sng.clear();
					}

				}
				else if(vec[0].compare("INR/USD") == 0){
				
					inr[key] = tick;
					if(sec == 59)
					{
						//cout<<"INR/USD"<<endl;
						ohlc(inr,"inr_usd");
						inr.clear();
					}

				}
				else{
					
				}
				
				vec.clear();
			}
				
		}
		sub();
	}

	void zmq_ohlc(map< array<int, 7>, string> sym,string symbol1){
					
					int temp = 0, temp1 = 0, highbuy = -2147483648 , lowbuy = 2147483647 , highsell = -2147483648, lowsell = 2147483647 , high, low;
					std::string openbuy, closebuy, opensell, closesell,word;
					int count = 1, b = 1, s = 1, x = 1;
					std::string tempstr,time,ohlc_sell1,ohlc_buy1;

					// zmq::context_t context(1);
					// zmq::socket_t publisher(context, ZMQ_PUB);
					// publisher.bind("tcp://*:5432");
					// usleep(200000);


					//cout <<"one minute data : "<<endl;
					for (auto itr = sym.begin(); itr != sym.end(); ++itr) {
						//cout << itr->first[5] << ',' << itr->second << endl;
						if (count == 1)
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (b == 1)
								{
									openbuy = tempstr;
								}
								if (b == 2)
								{
									opensell = tempstr;
								}
								b++;
							}

						}
						
						if (count == sym.size())
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (s == 1)
								{
									closebuy = tempstr;
								}
								if (s == 2)
								{
									closesell = tempstr;
								}
								s++;
							}
							time = std::to_string(itr->first[0])+'-'+std::to_string(itr->first[1])+'-'+std::to_string(itr->first[2])+'-'+std::to_string(itr->first[3])+'-'+std::to_string(itr->first[4])+'-'+std::to_string(itr->first[5]);
						}
						
						std::stringstream ss(itr->second);
						while (getline(ss, word, ',')) {
							tempstr = word;
							if (x == 1)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highbuy < high)
								{
									
									highbuy = high;
								}
								
								if (lowbuy > low)
								{
									
									lowbuy = low;
								}

							}
							if (x == 2)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highsell < high)
								{
									
									highsell = high;
								}
								
								if (lowsell > low)
								{	
									lowsell = low;
								}
								
							}
							x++;

						}
						x = 1;
						
						count++;
					}
						 symbol=symbol1;
						 ohlc_buy = time+","+openbuy+","+std::to_string(highbuy)+","+std::to_string(lowbuy)+","+closebuy;
						 ohlc_sell = time+","+opensell+","+std::to_string(highsell)+","+std::to_string(lowsell)+","+closesell;
						s_sendmore (Con::publisher, "ohlc_sell_"+symbol);
            			s_send (Con::publisher, ohlc_sell);
						s_sendmore (Con::publisher, "ohlc_buy_"+symbol);
            			s_send (Con::publisher, ohlc_buy);

					cout << "Time : " << time << " openbuy ::" << openbuy << " highbuy ::" << highbuy << " lowbuy ::" << lowbuy << " closebuy ::" << closebuy << endl;
					cout << "Time : " << time << " opensell ::" << opensell << " highsell ::" << highsell << " lowsell ::" << lowsell << " closesell ::" << closesell << endl;

			sym.clear();
	}
	
	
};
int main()
{
	int sa;
	chartserver s;

	s.fohlc();
	//s.sub();
	
		cin >> sa;
	return 0;
}

// g++ Source.cpp -lapr-1 -laprutil-1 -lzmq -llog4cxx -o sourceop