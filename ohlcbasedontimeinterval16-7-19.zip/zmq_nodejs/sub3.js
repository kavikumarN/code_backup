"use strict";
const
    zmq = require('zeromq'),
    subscriber = zmq.socket('sub');

// Subscribe to all messages.
subscriber.subscribe('ohlc_buy_inr');

// Handle messages from publisher.
subscriber.on('message', function (symbol,data) {
    
    console.log( symbol.toString());
    console.log(data.toString());
    
});


// Connect to publisher.
subscriber.connect('tcp://localhost:5432');
