#include <random>
#include "zhelpers.hpp"
using namespace std;
int main () {
    int sa=0;
    string  str="0,0,0,0,0,0,0,0";
    //  Prepare our context and publisher
    zmq::context_t context(1);
    zmq::socket_t publisher(context, ZMQ_PUB);
    publisher.bind("tcp://*:5553");
    sleep(1);
    s_sendmore (publisher, "tickdata");
    s_send (publisher, str);
    while (sa<100) {
        //random number genration
        std::random_device rd; // obtain a random number from hardware
	    std::mt19937 eng(rd()); // seed the generator
		std::uniform_int_distribution<> distr(10000, 99999); // define the range
        int rand1 = distr(eng),rand2 = distr(eng);
        
        // current date/time based on current system
		time_t now = time(0);

		//cout << "Number of sec since January 1,1900:" << ctime(&now) << endl;

		tm *ltm = localtime(&now);

		//1900 + ltm->tm_year << ',' << 1 + ltm->tm_mon << ',' << ltm->tm_mday << ',' << ltm->tm_hour << ',' << ltm->tm_min << ',' << ltm->tm_sec << endl;

        str = std::to_string(rand1)+","+std::to_string(rand2)+","+std::to_string(1900 + ltm->tm_year)+","+std::to_string(1 + ltm->tm_mon)+","+std::to_string(ltm->tm_mday)+","+std::to_string(ltm->tm_hour)+","+std::to_string(ltm->tm_min)+","+std::to_string(ltm->tm_sec);
        std::cout << str << endl;
        //  Write two messages, each with an envelope and content
        s_sendmore (publisher, "A");
        s_send (publisher, str);
        s_sendmore (publisher, "B");
        s_send (publisher, "We would like to see this");
        sa++;
        sleep (1);
    }
    publisher.close();
    context.close();
    return 0;
}

// g++ publisher.cpp -lzmq -o publisher