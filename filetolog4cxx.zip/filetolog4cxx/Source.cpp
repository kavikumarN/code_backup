#include "zhelpers.hpp"
#include <iostream>
#include <ctime>
#include <random>
#include <map>
#include <vector>
#include <fstream>
#include <sstream>
#include <unistd.h>
#include <array>
#include <climits>
#include <log4cxx/logger.h>
#include <log4cxx/basicconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/helpers/stringhelper.h>
#include <log4cxx/xml/domconfigurator.h>
#include <log4cxx/helpers/exception.h>
#include <log4cxx/ndc.h>
#include <log4cxx/level.h>
#include <sstream>
#include <string>

using namespace std;
using namespace log4cxx;
using namespace log4cxx::helpers;
class chartserver
{
public:
std::stringstream stringbuy;
std::stringstream stringsell;
int flag=1;
int result = EXIT_SUCCESS;
enum {LOG4CXX_POLL_INTERVAL = 60, };
const char* LOG4CXX_PROPERTY_FILE ="config.xml";

	map< array<int, 7>, string> eur;
	map< array<int, 7>, string> aur;
	map< array<int, 7>, string> can;
	map< array<int, 7>, string> sng;
	map< array<int, 7>, string> inr;
	
	void sub(){

		cout<<"Subscriber : "<<endl;
		
		string word,tick; 
		array<int, 7> key;
		

		std::vector<std::string> vec;

		zmq::context_t context(1);
    	zmq::socket_t subscriber (context, ZMQ_SUB);
    	subscriber.connect("tcp://localhost:5553");
    	subscriber.setsockopt( ZMQ_SUBSCRIBE,"tickdata",1);
        
		 while (1) {
			 
			//  Read envelope with address
			std::string address = s_recv (subscriber);
			//  Read message contents
			std::string contents = s_recv (subscriber);

			std::stringstream ss(contents);

				while (getline(ss, word, ',')) {
					vec.push_back(word);
			}
			if (vec.size() > 0) {
				//int sym_cnt=1;
				tick = tick = vec.at(1) + "," + vec.at(2);
				key = { std::stoi(vec.at(3)),std::stoi(vec.at(4)),std::stoi(vec.at(5)),std::stoi(vec.at(6)),std::stoi(vec.at(7)),std::stoi(vec.at(8)) };
			
				 	int sec = std::stoi(vec.at(8));
					//int min = std::stoi(vec.at(7));

				if(vec[0].compare("EUR/USD") == 0){
					
					eur[key] = tick;
					zmq_ohlc(eur);
					if(sec == 59)
					{
						cout<<"EUR/USD"<<endl;
						ohlc(eur,"eur_usd");
						eur.clear();
					}

				}
				else if(vec[0].compare("AUR/USD") == 0){
				
					aur[key] = tick;
					zmq_ohlc(aur);
					if(sec == 59)
					{
						cout<<"AUR/USD"<<endl;
						ohlc(aur,"aur_usd");
						aur.clear();
					}

				}
				else if(vec[0].compare("CAN/USD") == 0){
				
					can[key] = tick;
					zmq_ohlc(can);
					if(sec == 59)
					{
						cout<<"CAN/USD"<<endl;
						ohlc(can,"can_usd");
						can.clear();
					}

				}
				else if(vec[0].compare("SNG/USD") == 0){
				
					sng[key] = tick;
					zmq_ohlc(sng);
					if(sec == 59)
					{
						cout<<"SNG/USD"<<endl;
						ohlc(sng,"sng_usd");
						sng.clear();
					}

				}
				else if(vec[0].compare("INR/USD") == 0){
				
					inr[key] = tick;
					zmq_ohlc(inr);
					if(sec == 59)
					{
						cout<<"INR/USD"<<endl;
						ohlc(inr,"inr_usd");
						inr.clear();
					}

				}
				else{
					
				}
				
				vec.clear();
			}

    	}
	}
	void ohlc(map< array<int, 7>, string> sym,string fname){

		if(flag=1){
		    log4cxx::xml::DOMConfigurator::configureAndWatch(LOG4CXX_PROPERTY_FILE,LOG4CXX_POLL_INTERVAL);
				LoggerPtr rootLogger = Logger::getLogger("");
		         NDC::push("trivial context");
				 flag++;
		}
	
				
				LoggerPtr rootLogger = Logger::getLogger("");

		         NDC::push("trivial context");

					int temp = 0, temp1 = 0, highbuy = -2147483648 , lowbuy = 2147483647 , highsell = -2147483648, lowsell = 2147483647 , high, low;
					std::string openbuy, closebuy, opensell, closesell,word;
					int count = 1, b = 1, s = 1, x = 1;
					std::string tempstr,time;

					 // open a file in write mode.
						ofstream outfile_buy;
						ofstream outfile_sell;
						outfile_buy.open("/home/lk/Documents/worklog/july/9/filereading/"+fname+"_buy.csv", ios::app);
						outfile_sell.open("/home/lk/Documents/worklog/july/9/filereading/"+fname+"_sell.csv", ios::app);
					cout <<"one minute data : "<<endl;
					for (auto itr = sym.begin(); itr != sym.end(); ++itr) {
						// cout << itr->first[0] << itr->first[1] << itr->first[2] << itr->first[3] << itr->first[4] << itr->first[5] << ',' << itr->second << endl;
						if (count == 1)
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (b == 1)
								{
									openbuy = tempstr;
								}
								if (b == 2)
								{
									opensell = tempstr;
								}
								b++;
							}

						}
						
						if (count == sym.size())
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (s == 1)
								{
									closebuy = tempstr;
								}
								if (s == 2)
								{
									closesell = tempstr;
								}
								s++;
							}
							time = std::to_string(itr->first[0])+'-'+std::to_string(itr->first[1])+'-'+std::to_string(itr->first[2])+'-'+std::to_string(itr->first[3])+'-'+std::to_string(itr->first[4]);
							//cout << itr->first[0] << itr->first[1] << itr->first[2] << itr->first[3] << itr->first[4] << itr->first[5] << ',' << itr->second << endl;
						}
						
						std::stringstream ss(itr->second);
						
						while (getline(ss, word, ',')) {
							tempstr = word;
							if (x == 1)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highbuy < high)
								{
									
									highbuy = high;
								}
								
								if (lowbuy > low)
								{
									
									lowbuy = low;
								}

							}
							if (x == 2)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highsell < high)
								{
									
									highsell = high;
								}
								
								if (lowsell > low)
								{
									
									lowsell = low;
								}
								
							}
							x++;

						}
						x = 1;
						
						count++;
					}

					stringbuy <<time<<','<<openbuy<<','<<highbuy<<','<<lowbuy<<','<<closebuy<<endl;
					stringsell <<time<<','<<opensell<<','<<highsell<<','<<lowsell<<','<<closesell<<endl;
					//cout << "Time :" << time <<"openbuy ::" << openbuy << "highbuy ::" << highbuy << "lowbuy ::" << lowbuy << "closebuy ::" << closebuy << endl;
					cout << "Time :" << time << "opensell ::" << opensell << "highsell ::" << highsell << "lowsell ::" << lowsell << "closesell ::" << closesell << endl;
				    std::string ssell = stringbuy.str();
					std::string sbuy = stringsell.str();

					rootLogger->info(ssell); //info == sell
					rootLogger->error(sbuy);  // error == buy

					sym.clear();

	}	
	
	void fohlc()
	{

		
		
		string word,tick,data; 
		array<int, 7> key;
		

		std::vector<std::string> vec;

		// open a file in write mode.
		ifstream infile;
		infile.open("data.csv");

		// Execute a loop until EOF (End of File) 
		cout << "File Reading : \n";
		while (infile) {

			// Read a Line from File 
			getline(infile, data);
			//add data to vector
			std::stringstream ss(data);

			while (getline(ss, word, ',')) {
				vec.push_back(word);
			}
			if (vec.size() > 0) {

				tick = tick = vec.at(1) + "," + vec.at(2);
				
				key = { std::stoi(vec.at(3)),std::stoi(vec.at(4)),std::stoi(vec.at(5)),std::stoi(vec.at(6)),std::stoi(vec.at(7)),std::stoi(vec.at(8)) };
			
				 	int sec = std::stoi(vec.at(8));
					//int min = std::stoi(vec.at(7));

				if(vec[0].compare("EUR/USD") == 0){
					
					eur[key] = tick;
					if(sec == 59)
					{
						cout<<"EUR/USD"<<endl;
						ohlc(eur,"eur_usd");
						eur.clear();
					}

				}
				else if(vec[0].compare("AUR/USD") == 0){
				
					aur[key] = tick;
					if(sec == 59)
					{
						cout<<"AUR/USD"<<endl;
						ohlc(aur,"aur_usd");
						aur.clear();
					}

				}
				else if(vec[0].compare("CAN/USD") == 0){
				
					can[key] = tick;
					if(sec == 59)
					{
						cout<<"CAN/USD"<<endl;
						ohlc(can,"can_usd");
						can.clear();
					}

				}
				else if(vec[0].compare("SNG/USD") == 0){
				
					sng[key] = tick;
					if(sec == 59)
					{
						cout<<"SNG/USD"<<endl;
						ohlc(sng,"sng_usd");
						sng.clear();
					}

				}
				else if(vec[0].compare("INR/USD") == 0){
				
					inr[key] = tick;
					if(sec == 59)
					{
						cout<<"INR/USD"<<endl;
						ohlc(inr,"inr_usd");
						inr.clear();
					}

				}
				else{
					
				}
				
				vec.clear();
			}
				
		}
		
	}

	void zmq_ohlc(map< array<int, 7>, string> sym){
					
					int temp = 0, temp1 = 0, highbuy = -2147483648 , lowbuy = 2147483647 , highsell = -2147483648, lowsell = 2147483647 , high, low;
					std::string openbuy, closebuy, opensell, closesell,word;
					int count = 1, b = 1, s = 1, x = 1;
					std::string tempstr,time,ohlc_sell,ohlc_buy;
					
					//  Prepare our context and publisher
					zmq::context_t context(1);
					zmq::socket_t publisher(context, ZMQ_PUB);
					publisher.bind("tcp://*:5432");
					usleep(300000);

					cout <<"one minute data : "<<endl;
					for (auto itr = sym.begin(); itr != sym.end(); ++itr) {
						//cout << itr->first[5] << ',' << itr->second << endl;
						if (count == 1)
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (b == 1)
								{
									openbuy = tempstr;
								}
								if (b == 2)
								{
									opensell = tempstr;
								}
								b++;
							}

						}
						
						if (count == sym.size())
						{
							
							std::stringstream ss(itr->second);
							while (getline(ss, word, ',')) {
								tempstr = word;
								if (s == 1)
								{
									closebuy = tempstr;
								}
								if (s == 2)
								{
									closesell = tempstr;
								}
								s++;
							}
							time = std::to_string(itr->first[0])+'-'+std::to_string(itr->first[1])+'-'+std::to_string(itr->first[2])+'-'+std::to_string(itr->first[3])+'-'+std::to_string(itr->first[4]);
						}
						
						std::stringstream ss(itr->second);
						while (getline(ss, word, ',')) {
							tempstr = word;
							if (x == 1)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highbuy < high)
								{
									
									highbuy = high;
								}
								
								if (lowbuy > low)
								{
									
									lowbuy = low;
								}

							}
							if (x == 2)
							{
								std::stringstream ss(tempstr);
								ss >> high;
								std::stringstream s(tempstr);
								s >> low;
								
								if (highsell < high)
								{
									
									highsell = high;
								}
								
								if (lowsell > low)
								{
									
									lowsell = low;
								}
								
							}
							x++;

						}
						x = 1;
						
						count++;
					}
					sym.clear();
						//  ohlc_buy = time+','+openbuy+','+highbuy+',';
						//  s_sendmore (publisher, "ohlc_sell");
            			//  s_send (publisher, ohlc_sell);
						//  s_sendmore (publisher, "ohlc_buy");
            			//  s_send (publisher, ohlc_buy);
					cout << "Time : " << time << " openbuy ::" << openbuy << " highbuy ::" << highbuy << " lowbuy ::" << lowbuy << " closebuy ::" << closebuy << endl;
					cout << "Time : " << time << " opensell ::" << opensell << " highsell ::" << highsell << " lowsell ::" << lowsell << " closesell ::" << closesell << endl;
	}
	
	
};
int main()
{
	int sa;
	chartserver s;
	
	s.fohlc();
	s.sub();
	
	cin >> sa;
	return 0;
}


//  g++ Source.cpp  -lapr-1 -laprutil-1 -lzmq -llog4cxx -o source