#include <iostream>
#include <log4cxx/logger.h>
#include <log4cxx/logmanager.h>
#include <log4cxx/xml/domconfigurator.h>
#include <log4cxx/fileappender.h>
#include <log4cxx/simplelayout.h>
#include <log4cxx/helpers/transcoder.h>
#include <thread> 

void func(std::string k) {
    std::string strName = "Log"+k;
    log4cxx::LoggerPtr log = log4cxx::Logger::getLogger(strName);
    LOG4CXX_DECODE_CHAR(fileName, strName + ".csv");
    log4cxx::FileAppenderPtr appender(new log4cxx::FileAppender(new log4cxx::SimpleLayout, fileName, false));
    log->addAppender(appender);

    LOG4CXX_INFO(log, strName);

    log->removeAppender(appender);
}

int main(int argc, char * argv[]) {
    log4cxx::xml::DOMConfigurator::configure("log4cxx.xml");
    if(log4cxx::Logger::getLogger("Log")->getAllAppenders().empty()) {
        std::cout << "failed to config log4cxx" << std::endl;
        return 1;
    }
    log4cxx::LoggerPtr log = log4cxx::Logger::getLogger("Log");


	    std::thread th1(func,"test1"); 
        std::thread th2(func,"test2");
        std::thread th3(func,"test3"); 
        th1.join();
        th2.join();
        th3.join();
    return 0;
}

// g++ log4cxx.cpp  -lapr-1 -laprutil-1 -llog4cxx -lzmq -o output
